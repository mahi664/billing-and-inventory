package com.example.demo.POJO;

public class CategoryDetailsBO {
	private 	String 		categoryId;
	private 	String 		categoryName;
	private 	String 		categoryDispName;
	private 	String 		categoryDescription;
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getCategoryDispName() {
		return categoryDispName;
	}
	public void setCategoryDispName(String categoryDispName) {
		this.categoryDispName = categoryDispName;
	}
	public String getCategoryDescription() {
		return categoryDescription;
	}
	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}
	
	
}
