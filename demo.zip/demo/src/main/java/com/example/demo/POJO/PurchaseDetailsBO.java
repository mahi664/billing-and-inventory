package com.example.demo.POJO;

import java.util.ArrayList;

public class PurchaseDetailsBO {
	private 	int 							dateSkey;
	private 	String 							vendor;
	
	private 	ArrayList<ProductDetailsBO>		productsList = 		null;

	public int getDateSkey() {
		return dateSkey;
	}

	public void setDateSkey(int dateSkey) {
		this.dateSkey = dateSkey;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public ArrayList<ProductDetailsBO> getProductsList() {
		return productsList;
	}

	public void setProductsList(ArrayList<ProductDetailsBO> productsList) {
		this.productsList = productsList;
	}
	
	
}
