package com.example.demo.Controllers;

import java.awt.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.POJO.CustomerDetailsBO;
import com.example.demo.Services.CustomerDataService;

@RestController(value="/customer")
public class CustomerController {
	
	@Autowired
	private CustomerDataService customerDataService;
	
	@GetMapping(path="/customer")
	public ArrayList<CustomerDetailsBO> getAllCustomers(){
		return customerDataService.getAllCustomersDetails();
	}
}
